<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(strlen($_SESSION['alogin'])==0)
    {   
header('location:index.php');
}
else{ 

if(isset($_POST['updatevideo']))
{
$videoname=$_POST['videoname'];
$videotype=$_POST['videotype'];
$videoreg=$_POST['videoreg'];
$videoact=$_POST['videoact'];
$videocode=$_POST['videocode'];
$videogen=$_POST['videogen'];
$videoprice=$_POST['videoprice'];
$videoid=intval($_GET['videoid']);
$sql="update tblvideo set VideoName=:videoname,VideoType=:videotype,VideoProd=:videoreg,VideoAct=:videoact,VideoCode=:videocode,VideoGenre=:videogen,VideoPrice=:videoprice where id=:videoid";
$query = $dbh->prepare($sql);
$query->bindParam(':videoname',$videoname,PDO::PARAM_STR);
$query->bindParam(':videotype',$videotype,PDO::PARAM_STR);
$query->bindParam(':videoreg',$videoreg,PDO::PARAM_STR);
$query->bindParam(':videoact',$videoact,PDO::PARAM_STR);
$query->bindParam(':videocode',$videocode,PDO::PARAM_STR);
$query->bindParam(':videogen',$videogen,PDO::PARAM_STR);
$query->bindParam(':videoprice',$videoprice,PDO::PARAM_STR);
$query->bindParam(':videoid',$videoid,PDO::PARAM_STR);
$query->execute();
$_SESSION['msg']="Video actualizat cu succes!";
header('location:manage-videos.php');


}
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Editeaza video</title>
    <!-- BOOTSTRAP CORE STYLE  -->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONT AWESOME STYLE  -->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!-- CUSTOM STYLE  -->
    <link href="assets/css/style.css" rel="stylesheet" />
    <!-- GOOGLE FONT -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />

</head>
<body>
      <!------MENU SECTION START-->
<?php include('includes/header.php');?>
<!-- MENU SECTION END-->
    <div class="content-wra
    <div class="content-wrapper">
         <div class="container">
        <div class="row pad-botm">
            <div class="col-md-12">
                <h4 class="header-line">Editeaza Video</h4>
                
                            </div>

</div>
<div class="row">
<div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3"">
<div class="panel panel-info">
<div class="panel-heading">
Informatii Video
</div>
<div class="panel-body">
<form role="form" method="post">
<?php 
$videoid=intval($_GET['videoid']);
$sql = "SELECT * from tblvideo where id=:videoid";
$query = $dbh -> prepare($sql);
$query->bindParam(':videoid',$videoid,PDO::PARAM_STR);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query->rowCount() > 0)
{
foreach($results as $result)
{               ?>  

<div class="form-group">
<label>Denumire<span style="color:red;">*</span></label>
<input class="form-control" type="text" name="videoname" value="<?php echo htmlentities($result->VideoName);?>" required />
</div>

<div class="form-group">
<label>Tip<span style="color:red;">*</span></label>
<input class="form-control" type="text" name="videotype" value="<?php echo htmlentities($result->VideoType);?>" required />
</div>

<div class="form-group">
<label>Regizor<span style="color:red;">*</span></label>
<input class="form-control" type="text" name="videoreg" value="<?php echo htmlentities($result->VideoProd);?>" required />
</div>

<div class="form-group">
<label>Actori<span style="color:red;">*</span></label>
<input class="form-control" type="text" name="videoact" value="<?php echo htmlentities($result->VideoAct);?>" required />
</div>

<div class="form-group">
<label>Cod unic<span style="color:red;">*</span></label>
<input class="form-control" type="text" name="videocode" value="<?php echo htmlentities($result->VideoCode);?>" required />
</div>

<div class="form-group">
<label>Gen<span style="color:red;">*</span></label>
<input class="form-control" type="text" name="videogen" value="<?php echo htmlentities($result->VideoGenre);?>" required />
</div>

<div class="form-group">
<label>Pret<span style="color:red;">*</span></label>
<input class="form-control" type="text" name="videoprice" value="<?php echo htmlentities($result->VideoPrice);?>" required />
</div>


 <?php }} ?>
<button type="submit" name="updatevideo" class="btn btn-info">Update </button>

                                    </form>
                            </div>
                        </div>
                            </div>

        </div>
   
    </div>
    </div>
     <!-- CONTENT-WRAPPER SECTION END-->
  <?php include('includes/footer.php');?>
      <!-- FOOTER SECTION END-->
    <!-- JAVASCRIPT FILES PLACED AT THE BOTTOM TO REDUCE THE LOADING TIME  -->
    <!-- CORE JQUERY  -->
    <script src="assets/js/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="assets/js/bootstrap.js"></script>
      <!-- CUSTOM SCRIPTS  -->
    <script src="assets/js/custom.js"></script>
</body>
</html>
<?php } ?>
